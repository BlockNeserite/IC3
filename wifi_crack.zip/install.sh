#!/bin/bash

# Установочный скрипт для WiFi Fake AP & Handshake Catcher
# Поддержка: Kali Linux, Ubuntu, Debian, Raspberry Pi OS

echo "╔════════════════════════════════════════════╗"
echo "║  WiFi Fake AP - Installation Script       ║"
echo "╚════════════════════════════════════════════╝"
echo ""

# Проверка прав root
if [ "$EUID" -ne 0 ]; then
    echo "[!] Требуются права root"
    echo "[!] Запустите: sudo bash install.sh"
    exit 1
fi

# Определение дистрибутива
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$ID
    echo "[*] Обнаружена ОС: $PRETTY_NAME"
else
    echo "[!] Не удалось определить ОС"
    exit 1
fi

echo ""
echo "[*] Обновление списка пакетов..."
apt update

echo ""
echo "[*] Установка основных зависимостей..."
apt install -y \
    aircrack-ng \
    hostapd \
    python3 \
    python3-pip \
    iw \
    wireless-tools \
    net-tools

echo ""
echo "[*] Установка Python зависимостей..."
pip3 install -r requirements.txt

echo ""
echo "[*] Установка дополнительных инструментов..."

# hcxtools - для конвертации в hashcat формат
if ! command -v hcxpcaptool &> /dev/null; then
    echo "    - hcxtools (для hashcat формата)"
    apt install -y hcxtools 2>/dev/null || echo "    [!] hcxtools недоступен в репозитории (опционально)"
fi

echo ""
echo "[*] Установка прав на выполнение скриптов..."
chmod +x fake_ap.py fake_ap_simple.py

echo ""
echo "╔════════════════════════════════════════════╗"
echo "║         Установка завершена!               ║"
echo "╚════════════════════════════════════════════╝"
echo ""
echo "Установленные компоненты:"
echo "  ✓ aircrack-ng suite"
echo "  ✓ hostapd"
echo "  ✓ Python 3 + scapy"
echo "  ✓ Дополнительные утилиты"
echo ""
echo "Использование:"
echo "  sudo python3 fake_ap.py wlan0 'Free WiFi' 00:11:22:33:44:55 6"
echo "  или"
echo "  sudo python3 fake_ap_simple.py wlan0mon 'Target Network'"
echo ""
echo "Документация: см. README.md"
echo ""
