#!/bin/bash

# Скрипт проверки WiFi адаптера на совместимость
# Определяет чипсет и поддержку monitor mode

echo "╔════════════════════════════════════════════╗"
echo "║   WiFi Adapter Compatibility Checker       ║"
echo "╚════════════════════════════════════════════╝"
echo ""

# Проверка прав root
if [ "$EUID" -ne 0 ]; then
    echo "[!] Для полной проверки нужны права root"
    echo "[!] Запустите: sudo bash check_adapter.sh"
    echo ""
fi

echo "[*] Поиск WiFi адаптеров..."
echo ""

# USB устройства
echo "=== USB WiFi адаптеры ==="
lsusb | grep -i "wireless\|802.11\|wifi\|wlan\|atheros\|ralink\|realtek\|tp-link"

echo ""
echo "=== Детальная информация ==="

# Список всех беспроводных интерфейсов
for iface in $(ls /sys/class/net/ | grep -E "wlan|wlp"); do
    echo ""
    echo "─────────────────────────────────────────"
    echo "Интерфейс: $iface"
    echo "─────────────────────────────────────────"

    # Получаем информацию о чипсете
    if [ -e "/sys/class/net/$iface/device/uevent" ]; then
        DRIVER=$(cat /sys/class/net/$iface/device/uevent | grep DRIVER | cut -d'=' -f2)
        echo "Драйвер: $DRIVER"
    fi

    # USB ID (Vendor:Product)
    if [ -e "/sys/class/net/$iface/device/uevent" ]; then
        PRODUCT=$(cat /sys/class/net/$iface/device/uevent | grep PRODUCT | cut -d'=' -f2)
        if [ ! -z "$PRODUCT" ]; then
            echo "USB ID: $PRODUCT"

            # Определяем производителя и модель
            VID=$(echo $PRODUCT | cut -d'/' -f1)
            PID=$(echo $PRODUCT | cut -d'/' -f2)

            case "$VID/$PID" in
                "cf3/9271")
                    echo "✅ Чипсет: Atheros AR9271"
                    echo "✅ Модель: TL-WN722N v1 или аналог"
                    echo "✅ Monitor mode: ПОДДЕРЖИВАЕТСЯ"
                    echo "✅ Packet injection: ПОДДЕРЖИВАЕТСЯ"
                    ;;
                "cf3/1006")
                    echo "❌ Чипсет: Realtek RTL8188EUS"
                    echo "❌ Модель: TL-WN722N v2"
                    echo "❌ Monitor mode: НЕ ПОДДЕРЖИВАЕТСЯ"
                    ;;
                "cf3/300d")
                    echo "❌ Чипсет: Realtek RTL8188FTV"
                    echo "❌ Модель: TL-WN722N v3"
                    echo "❌ Monitor mode: НЕ ПОДДЕРЖИВАЕТСЯ"
                    ;;
                "b05/17d2")
                    echo "✅ Чипсет: Ralink RT5372"
                    echo "✅ Модель: Alfa AWUS036NH или аналог"
                    echo "✅ Monitor mode: ПОДДЕРЖИВАЕТСЯ"
                    ;;
                "846/9030"|"846/9041")
                    echo "✅ Чипсет: Ralink RT5370"
                    echo "✅ Monitor mode: ПОДДЕРЖИВАЕТСЯ"
                    ;;
                *)
                    echo "⚠️  Чипсет: Неизвестен (ID: $VID/$PID)"
                    echo "⚠️  Требуется дополнительная проверка"
                    ;;
            esac
        fi
    fi

    # MAC адрес
    MAC=$(cat /sys/class/net/$iface/address 2>/dev/null)
    echo "MAC адрес: $MAC"

    # Проверка режимов (требует root)
    if [ "$EUID" -eq 0 ]; then
        echo ""
        echo "Поддерживаемые режимы:"
        iw phy$(cat /sys/class/net/$iface/phy80211/name 2>/dev/null || echo "phy0") info | grep -A 10 "Supported interface modes" | grep "*" | sed 's/^[[:space:]]*/  /'

        # Проверка monitor mode
        if iw phy$(cat /sys/class/net/$iface/phy80211/name 2>/dev/null || echo "phy0") info | grep -q "monitor"; then
            echo ""
            echo "✅ MONITOR MODE: ПОДДЕРЖИВАЕТСЯ"
        else
            echo ""
            echo "❌ MONITOR MODE: НЕ ПОДДЕРЖИВАЕТСЯ"
        fi
    fi
done

echo ""
echo "─────────────────────────────────────────"
echo ""

# Проверка установленных инструментов
echo "=== Проверка инструментов ==="
echo ""

check_tool() {
    if command -v $1 &> /dev/null; then
        echo "✅ $1 установлен"
    else
        echo "❌ $1 НЕ установлен"
    fi
}

check_tool "airmon-ng"
check_tool "airodump-ng"
check_tool "aircrack-ng"
check_tool "hostapd"

echo ""

# Python модули
if python3 -c "import scapy" 2>/dev/null; then
    echo "✅ python3-scapy установлен"
else
    echo "❌ python3-scapy НЕ установлен"
fi

echo ""
echo "╔════════════════════════════════════════════╗"
echo "║              Рекомендации                  ║"
echo "╚════════════════════════════════════════════╝"
echo ""

if lsusb | grep -q "0cf3:9271"; then
    echo "✅ Обнаружен совместимый адаптер (Atheros AR9271)"
    echo "   Можно использовать для fake AP и monitor mode"
elif lsusb | grep -q "148f:5370\|148f:5372"; then
    echo "✅ Обнаружен совместимый адаптер (Ralink)"
    echo "   Можно использовать для fake AP и monitor mode"
else
    echo "⚠️  Совместимый адаптер не обнаружен"
    echo ""
    echo "Рекомендуемые адаптеры для покупки:"
    echo "  - TP-Link TL-WN722N v1 (Atheros AR9271)"
    echo "  - Alfa AWUS036NH (Ralink RT3070)"
    echo "  - Alfa AWUS036NHA (Atheros AR9271)"
    echo "  - Panda PAU09 (Ralink RT5372)"
    echo ""
    echo "⚠️  ИЗБЕГАЙТЕ:"
    echo "  - TP-Link TL-WN722N v2/v3 (Realtek чипсет)"
    echo "  - Дешевые no-name адаптеры"
fi

echo ""
