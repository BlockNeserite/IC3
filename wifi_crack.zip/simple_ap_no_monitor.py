#!/usr/bin/env python3
"""
Fake WiFi Access Point - БЕЗ Monitor Mode
Создает обычную точку доступа и логирует попытки подключения
Работает на любом WiFi адаптере с поддержкой AP mode (почти все)
"""

import os
import sys
import subprocess
import time
import signal
import re
from datetime import datetime
from pathlib import Path

class SimpleAP:
    def __init__(self, interface, ssid, password="12345678", channel=6):
        self.interface = interface
        self.ssid = ssid
        self.password = password
        self.channel = channel
        self.hostapd_conf = "/tmp/simple_ap.conf"
        self.hostapd_log = f"hostapd_{ssid}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
        self.attempts_log = f"attempts_{ssid}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        self.hostapd_process = None
        self.running = False

        # Создаем директорию для логов
        os.makedirs("logs", exist_ok=True)
        self.hostapd_log = os.path.join("logs", self.hostapd_log)
        self.attempts_log = os.path.join("logs", self.attempts_log)

    def check_root(self):
        """Проверка прав root"""
        if os.geteuid() != 0:
            print("[!] Требуются права root")
            print("[!] Запустите: sudo python3", sys.argv[0])
            sys.exit(1)

    def check_interface(self):
        """Проверка наличия интерфейса"""
        result = subprocess.run(['ip', 'link', 'show', self.interface],
                              capture_output=True, text=True)
        if result.returncode != 0:
            print(f"[!] Интерфейс {self.interface} не найден")
            print("\n[*] Доступные интерфейсы:")
            subprocess.run(['ip', 'link', 'show'])
            sys.exit(1)

    def stop_conflicting_services(self):
        """Остановка конфликтующих сервисов"""
        print("[*] Остановка конфликтующих сервисов...")

        services = ['NetworkManager', 'wpa_supplicant', 'dhcpcd']
        for service in services:
            subprocess.run(['systemctl', 'stop', service],
                         stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL)

        # Убиваем процессы, использующие интерфейс
        subprocess.run(['killall', 'wpa_supplicant'],
                      stdout=subprocess.DEVNULL,
                      stderr=subprocess.DEVNULL)

    def prepare_interface(self):
        """Подготовка интерфейса"""
        print(f"[*] Подготовка интерфейса {self.interface}...")

        # Выключаем интерфейс
        subprocess.run(['ip', 'link', 'set', self.interface, 'down'],
                      stdout=subprocess.DEVNULL)
        time.sleep(1)

        # Включаем интерфейс
        subprocess.run(['ip', 'link', 'set', self.interface, 'up'],
                      stdout=subprocess.DEVNULL)
        time.sleep(1)

        # Устанавливаем IP адрес для AP
        subprocess.run(['ip', 'addr', 'flush', 'dev', self.interface],
                      stdout=subprocess.DEVNULL)
        subprocess.run(['ip', 'addr', 'add', '192.168.10.1/24', 'dev', self.interface],
                      stdout=subprocess.DEVNULL)

        print(f"[+] Интерфейс подготовлен: 192.168.10.1")

    def create_hostapd_config(self):
        """Создание конфигурации hostapd"""
        print(f"[*] Создание конфигурации точки доступа...")

        # Расширенная конфигурация с логированием
        config = f"""# Интерфейс
interface={self.interface}
driver=nl80211

# Базовые настройки
ssid={self.ssid}
hw_mode=g
channel={self.channel}

# Логирование
logger_syslog=-1
logger_syslog_level=2
logger_stdout=-1
logger_stdout_level=2

# Управление доступом
macaddr_acl=0
auth_algs=3
ignore_broadcast_ssid=0

# WPA/WPA2 настройки
wpa=2
wpa_passphrase={self.password}
wpa_key_mgmt=WPA-PSK
wpa_pairwise=TKIP CCMP
rsn_pairwise=CCMP

# Дополнительно
ieee80211n=1
wmm_enabled=1

# Ограничения
max_num_sta=10
"""

        with open(self.hostapd_conf, 'w') as f:
            f.write(config)

        print(f"[+] Конфигурация создана: {self.hostapd_conf}")
        return self.hostapd_conf

    def log_event(self, message, to_file=True):
        """Логирование событий"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        log_message = f"[{timestamp}] {message}"

        print(log_message)

        if to_file:
            with open(self.attempts_log, 'a', encoding='utf-8') as f:
                f.write(log_message + '\n')

    def parse_hostapd_output(self, line):
        """Парсинг вывода hostapd для отслеживания подключений"""
        line = line.strip()

        # Новое подключение
        if 'AP-STA-CONNECTED' in line or 'associated' in line.lower():
            mac_match = re.search(r'([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})', line)
            if mac_match:
                mac = mac_match.group(0)
                self.log_event(f"[+] НОВОЕ ПОДКЛЮЧЕНИЕ! MAC: {mac}")
                return

        # Попытка аутентификации
        if 'authentication' in line.lower():
            mac_match = re.search(r'([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})', line)
            if mac_match:
                mac = mac_match.group(0)
                self.log_event(f"[*] Попытка аутентификации: {mac}")
                return

        # 4-way handshake
        if 'WPA' in line and 'handshake' in line.lower():
            mac_match = re.search(r'([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})', line)
            if mac_match:
                mac = mac_match.group(0)
                self.log_event(f"[+++] WPA HANDSHAKE НАЧАТ: {mac}")
                return

        if 'EAPOL' in line:
            mac_match = re.search(r'([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})', line)
            if mac_match:
                mac = mac_match.group(0)
                self.log_event(f"[***] EAPOL пакет от: {mac}")
                return

        # Отключение
        if 'AP-STA-DISCONNECTED' in line or 'disassociated' in line.lower():
            mac_match = re.search(r'([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})', line)
            if mac_match:
                mac = mac_match.group(0)
                self.log_event(f"[-] Отключение: {mac}")
                return

        # Неудачная попытка (неправильный пароль)
        if 'failed' in line.lower() or 'denied' in line.lower():
            mac_match = re.search(r'([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})', line)
            if mac_match:
                mac = mac_match.group(0)
                self.log_event(f"[!] НЕУДАЧНАЯ ПОПЫТКА (возможно неверный пароль): {mac}")
                return

    def start_hostapd(self):
        """Запуск hostapd"""
        print(f"\n[*] Запуск точки доступа '{self.ssid}'...")
        print(f"[*] Канал: {self.channel}")
        print(f"[*] Пароль: {self.password}")
        print(f"[*] IP адрес AP: 192.168.10.1")
        print(f"[*] Лог попыток: {self.attempts_log}")
        print(f"\n[*] Ожидание подключений...\n")

        # Запускаем hostapd с выводом в stdout
        self.hostapd_process = subprocess.Popen(
            ['hostapd', '-dd', self.hostapd_conf],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True,
            bufsize=1
        )

        self.running = True

        # Сохраняем полный лог hostapd
        with open(self.hostapd_log, 'w') as log_file:
            try:
                while self.running and self.hostapd_process.poll() is None:
                    line = self.hostapd_process.stdout.readline()
                    if line:
                        # Записываем в файл
                        log_file.write(line)
                        log_file.flush()

                        # Парсим интересные события
                        self.parse_hostapd_output(line)

            except KeyboardInterrupt:
                pass

    def start_dhcp_server(self):
        """Запуск простого DHCP сервера (опционально)"""
        # Проверяем наличие dnsmasq
        if subprocess.call(['which', 'dnsmasq'],
                          stdout=subprocess.DEVNULL,
                          stderr=subprocess.DEVNULL) == 0:

            print("[*] Запуск DHCP сервера...")

            dnsmasq_conf = f"""interface={self.interface}
dhcp-range=192.168.10.10,192.168.10.100,12h
dhcp-option=3,192.168.10.1
dhcp-option=6,8.8.8.8,8.8.4.4
"""

            conf_file = '/tmp/dnsmasq_ap.conf'
            with open(conf_file, 'w') as f:
                f.write(dnsmasq_conf)

            subprocess.Popen(
                ['dnsmasq', '-C', conf_file, '-d'],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )

            print("[+] DHCP сервер запущен (192.168.10.10-100)")

    def cleanup(self):
        """Очистка"""
        print("\n\n[*] Остановка точки доступа...")
        self.running = False

        if self.hostapd_process:
            self.hostapd_process.terminate()
            try:
                self.hostapd_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.hostapd_process.kill()

        # Останавливаем dnsmasq
        subprocess.run(['killall', 'dnsmasq'],
                      stdout=subprocess.DEVNULL,
                      stderr=subprocess.DEVNULL)

        # Очищаем интерфейс
        subprocess.run(['ip', 'addr', 'flush', 'dev', self.interface],
                      stdout=subprocess.DEVNULL)
        subprocess.run(['ip', 'link', 'set', self.interface, 'down'],
                      stdout=subprocess.DEVNULL)

        # Удаляем временные файлы
        for f in [self.hostapd_conf, '/tmp/dnsmasq_ap.conf']:
            if os.path.exists(f):
                os.remove(f)

        print("[+] Очистка завершена")
        print(f"\n[+] Логи сохранены:")
        print(f"    - Попытки подключения: {self.attempts_log}")
        print(f"    - Полный лог hostapd: {self.hostapd_log}")

    def run(self):
        """Основной запуск"""
        self.check_root()
        self.check_interface()

        self.log_event(f"=== Запуск Simple AP ===")
        self.log_event(f"SSID: {self.ssid}")
        self.log_event(f"Интерфейс: {self.interface}")
        self.log_event(f"Канал: {self.channel}")
        self.log_event(f"Пароль: {self.password}")

        self.stop_conflicting_services()
        self.prepare_interface()
        self.create_hostapd_config()

        # Запускаем DHCP (опционально)
        self.start_dhcp_server()

        # Обработка Ctrl+C
        def signal_handler(sig, frame):
            self.cleanup()
            sys.exit(0)

        signal.signal(signal.SIGINT, signal_handler)

        # Запускаем AP
        self.start_hostapd()


def main():
    print("""
╔════════════════════════════════════════════╗
║    Simple Fake WiFi AP (NO Monitor Mode)   ║
║        Работает на любом WiFi адаптере     ║
╚════════════════════════════════════════════╝
""")

    if len(sys.argv) < 3:
        print("Использование:")
        print(f"  {sys.argv[0]} <interface> <SSID> [password] [channel]")
        print("\nПримеры:")
        print(f"  {sys.argv[0]} wlan0 'Free WiFi'")
        print(f"  {sys.argv[0]} wlan0 'Starbucks' 'mypassword' 6")
        print(f"  {sys.argv[0]} wlan1 'Guest Network' '12345678' 11")
        print("\nПримечание:")
        print("  - Не требуется режим монитора")
        print("  - Работает на встроенном WiFi Raspberry Pi")
        print("  - Пароль должен быть минимум 8 символов")
        sys.exit(1)

    interface = sys.argv[1]
    ssid = sys.argv[2]
    password = sys.argv[3] if len(sys.argv) > 3 else "12345678"
    channel = int(sys.argv[4]) if len(sys.argv) > 4 else 6

    # Проверка пароля
    if len(password) < 8:
        print("[!] Пароль должен быть минимум 8 символов")
        password = "12345678"
        print(f"[*] Используется пароль по умолчанию: {password}")

    ap = SimpleAP(interface, ssid, password, channel)
    ap.run()


if __name__ == '__main__':
    main()
